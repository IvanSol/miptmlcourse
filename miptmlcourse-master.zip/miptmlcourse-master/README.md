# miptmlcourse
MIPT ML course Feb-May 2017: introduction to ML and DL

Slack: https://miptmlcourse.slack.com

Kaggle page on practical assignment #2: [link](https://inclass.kaggle.com/c/classroom-diabetic-retinopathy-detection-competition) 

## Videos

1. [Lecture 1](https://youtu.be/NIfFXmtLYyE)
2. [Lecture 2](https://youtu.be/auTkPTJ8MjU?t=1)
3. [Lecture 3](https://youtu.be/m7cimPZIgPk)
4. [Lecture 4](https://youtu.be/LcbMn1eI9gM?t=1)
5. [Lecture 5](https://youtu.be/BovOZwolIlY?t=1)
6. [Lecture 6](https://youtu.be/Z_iOm4z4nQc?t=1)
7. [Lecture 7](https://youtu.be/zV2eaKPEnEo?t=1)
